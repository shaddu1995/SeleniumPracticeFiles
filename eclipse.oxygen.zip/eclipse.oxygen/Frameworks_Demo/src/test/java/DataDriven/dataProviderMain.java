package DataDriven;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class dataProviderMain {
	
	WebDriver driver;
	@Test(dataProvider= "testData")
	public void printData(String name, String pwd) throws InterruptedException{
		System.out.println("name: "+name);
		System.out.println("password: "+pwd);	
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shraddha Nandagave\\eclipse-workspace\\chromedriver_win32 (1)\\chromedriver.exe");
		driver= new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);

		driver.get("https://facebook.com");
		Thread.sleep(2000);
		
		WebElement emailid= driver.findElement(By.id("email"));
		emailid.sendKeys(name);
		System.out.println("email entered");

		//enter password
		WebElement pass= driver.findElement(By.id("pass"));
		pass.sendKeys(pwd);
		System.out.println("pwd entered");

		Thread.sleep(2000);

		//click login button u_0_f
		WebElement loginButton= driver.findElement(By.id("u_0_b"));
		loginButton.submit();
		System.out.println("click login");
		Thread.sleep(5000);
		
		
		Thread.sleep(2000);
		try {
		Robot robo= new Robot();
		robo.mouseMove(460,97);
		robo.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		robo.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
		Thread.sleep(2000);		
		System.out.println("mouse event occured : robt class");
		
		}catch(Exception e) {
			System.out.println("can not close popup");
		}
		
		Thread.sleep(5000);
		System.out.println("came to an end!");
		WebElement select= driver.findElement(By.xpath("//*[@id=\"mount_0_0\"]/div/div[1]/div[1]/div[2]/div[4]/div[1]/span/div/div[1]"));
		select.click();
		Thread.sleep(5000);
		WebElement logOut= driver.findElement(By.xpath("//*[@id=\"mount_0_0\"]/div/div[1]/div[1]/div[2]/div[4]/div[2]/div/div[2]/div[1]/div[1]/div/div/div/div/div/div/div/div/div[1]/div/div[3]/div/div[4]/div/div[1]/div[2]/div/div/div/div/span"));
		logOut.click();
		Thread.sleep(5000);
		System.out.println("successful:LOGOUT!");
		
		driver.close();
		

	}
	@DataProvider
	public Object[][] testData()
	{
		String excelPath= "C:\\Users\\Shraddha Nandagave\\Desktop\\eclipse.oxygen\\Frameworks_Demo\\src\\test\\java\\DataDriven\\Book 1.xlsx";
		dataProviderExcel config= new dataProviderExcel(excelPath);
		int rows = config.getRowCount(0);
		
		Object[][] excelData = new Object[rows][2];
		
		for(int i=1; i<rows; i++ )
		{
			excelData[i][0] = config.getData(0, i, 0);
			excelData[i][1]=config.getData(0, i, 1);
			
			
		}
		
		return excelData;
		
	}
}
