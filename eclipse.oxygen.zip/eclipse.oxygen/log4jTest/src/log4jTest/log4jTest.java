package log4jTest;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.apache.log4j.xml.DOMConfigurator;

//import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;

public class log4jTest {

	private static WebDriver driver;

	private static Logger Log = Logger.getLogger(log4jTest.class.getName());

	public static void main(String[] args) {

		DOMConfigurator.configure("log4j.xml");

		System.getProperty("webdriver.chrome.driver", "C:\\Users\\Shraddha Nandagave\\eclipse-workspace\\chromedriver_win32 (1)\\chromedriver.exe");

		driver = new ChromeDriver();

		Log.info("New driver instantiated");

		//Put a Implicit wait, this means that any search for elements on the page could take the time the implicit wait is set for before throwing exception

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Log.info("Implicit wait applied on the driver for 10 seconds");

		//Launch the Online Store Website



		driver.quit();

		Log.info("Browser closed");

	}

}