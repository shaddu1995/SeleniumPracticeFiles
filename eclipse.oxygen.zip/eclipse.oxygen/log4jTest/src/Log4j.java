
public class Log4j {

}
