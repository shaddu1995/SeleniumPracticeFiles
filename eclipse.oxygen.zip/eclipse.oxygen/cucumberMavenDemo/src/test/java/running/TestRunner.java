package running;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="src/test/resources/feature",
		glue={"definition"},
		//strict= true,
		dryRun=true,
		monochrome = true
		
		)

public class TestRunner {

}
