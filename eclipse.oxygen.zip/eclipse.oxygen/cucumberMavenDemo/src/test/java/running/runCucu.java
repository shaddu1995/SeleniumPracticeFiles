package running;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= "C:/Users/Shraddha Nandagave/Desktop/eclipse.oxygen/cucumberMavenDemo/src/test/java/features/feature.feature",
		glue="definitions"
		)

public class runCucu {
	
	

}
