package definitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class definitionsClass {
	
	@Given("^user on login page$")
	public void user_on_login_page() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.print("user on login pageo");
	    
	}

	@When("^title of login page is facebook$")
	public void title_of_login_page_is_facebook() {
		System.out.println("title of login page is facebook");
	}
	@Then("user enters username and password")
	public void user_enters_username_and_password() {
		System.out.println("user enters username and password");
	}
	@Then("close the web")
	public void close_the_web() {
		System.out.println("close the web");
	    	}


}
