package jacasel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class testWeb {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shraddha Nandagave\\eclipse-workspace\\chromedriver_win32 (1)\\chromedriver.exe");
	
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.youtube.com/");
		driver.manage().window().maximize();
		
		Actions action = new Actions(driver);
		System.out.println("window open");
		WebElement ele = driver.findElement(By.xpath("//input[@id=\"search\"]"));
		
		System.out.println("element created");
		ele.click();
		System.out.println("clicked");
		ele.sendKeys("selenium edureka");	
		
		driver.findElement(By.cssSelector("#search-icon-legacy > yt-icon > svg")).submit();
				
		System.out.println("Search done");
		
		System.out.println("ele.click");
		
		action.moveByOffset(10, 400);
		
		
		
		
			
		driver.quit();	
		
	}

}
