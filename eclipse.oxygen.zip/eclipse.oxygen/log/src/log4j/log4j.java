package log4j;

import java.util.logging.Logger;

//import org.apache.log4j.Logger;

public class log4j {

	private static Logger Log = Logger.getLogger(log4j.class.getName());
	public static void main(String[] args) 
	{ 
		Log.warning("hellooo");


	} 
} 



