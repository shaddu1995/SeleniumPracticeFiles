package testlogginggg;


import org.apache.log4j.Logger;


public class tester {
	public static Logger logg 
	= Logger.getLogger(tester.class.getName()); 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Create a Logger with class name GFG 
		

		// Call info method 
		logg.info("Message 1"); 
		logg.warn("hey");
		

	}

}


