package restassured;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class restassuredAPItest {
	@Test
	public void testcase1() {
		
		RestAssured.baseURI ="http://dummy.restapiexample.com/api/v1/employees";
		
		RequestSpecification httpReq = RestAssured.given();
		
		JSONObject bodyData = new JSONObject();
		
		bodyData.put("name", "shraddha");
		bodyData.put("salary", "800000");
		bodyData.put("age", "25");
		
		httpReq.request();
		httpReq.header("Content-Type","application/Json");
		
		httpReq.body(bodyData.toJSONString());// bodyData is ready
		
		
		Response APIresponse= httpReq.request(Method.POST, "/create");
		
		
		String responseString=APIresponse.getBody().asString();
		
		Assert.assertEquals(responseString.contains("Shraddha"), true);	
		
	}

}
