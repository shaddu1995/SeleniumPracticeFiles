package youTubePlayVideoTest;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

public class youTubePlayVideoTest_JAVAproj {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shraddha Nandagave\\eclipse-workspace\\chromedriver_win32 (1)\\chromedriver.exe");


		WebDriver driver = new ChromeDriver();
		driver.get("https://www.youtube.com/");
		driver.manage().window().maximize();
		
		JavascriptExecutor js= (JavascriptExecutor)driver;
		EventFiringWebDriver eventHandler=new EventFiringWebDriver(driver);
		
		System.out.println("window open");
		WebElement ele = eventHandler.findElement(By.xpath("//input[@id=\"search\"]"));

		System.out.println("element created");
		ele.click();
		System.out.println("clicked");
		ele.sendKeys("selenium training");	

		eventHandler.findElement(By.cssSelector("#search-icon-legacy > yt-icon > svg")).submit();
		System.out.println("Search done");
		System.out.println("ele.click");
		
		//JavascriptExecutor js= (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,300)");
		
		//js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(2000);
		eventHandler.findElement(By.id("meta")).click();
		Thread.sleep(10000);
		
		eventHandler.quit();	

	}
}
