package stringsDemo;

public class callClass1 extends classClass{
	classClass c;
	int k= c.x;
	
	
	void ext2() {
		
		
		System.out.println("3. ext2 classs");
		//System.out.println("classClass func is called"+ c.x + c.y);
		
	}
}
