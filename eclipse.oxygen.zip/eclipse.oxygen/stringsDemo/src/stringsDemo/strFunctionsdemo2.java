package stringsDemo;

public class strFunctionsdemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		callClass c=new callClass();		
		System.out.println("x= "+ c.x);
		System.out.println("y= "+ c.y);
		c.base();

		classClass d=new classClass();
		System.out.println("m= "+ d.m);
		System.out.println("y= "+ d.y);
		d.base();
		d.ext1();
		int hc=d.hashCode();
		System.out.println("hash code "+ hc);

		callClass1 c1= new callClass1();
		/*System.out.println("d.x= c1.x "+ (c1.x + 100));
		System.out.println("d.y= c1.y "+ c1.y);
		c1.base();
		c1.ext1();
		System.out.println("c1.Functs");
		c1.ext2();*/
		c1.base();// error: protected
		System.out.println("d.y= "+ c1.y);

		@SuppressWarnings("unused")
		int x1 = c1.x;
		System.out.println("x+y= "+ (d.x+d.y));


	}

}
