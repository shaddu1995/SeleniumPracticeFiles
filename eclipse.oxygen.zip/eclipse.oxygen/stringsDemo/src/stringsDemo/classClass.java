package stringsDemo;

public class classClass extends callClass {
	
	callClass c=new callClass();
	int m=c.x;
	int n= c.y;
	
	void ext1() {
		System.out.println("2. ext1 class");
	}
	

}
