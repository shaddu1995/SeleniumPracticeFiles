package stringsDemo;

public class stringsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*String str="Shraddha";
		String str1="Shraddha";
		String str2="shraddha";
		String str3=new String("shraddha");*/
		
		String str_x="shraddha1";
		String str_y=new String("shraddha1");
		String str_z="shraddha1";
		String str_m=new String("shraddha1");
		
		
		if(str_y == str_z)
			System.out.println("str_y=str_z");
		if(str_z == str_x)
			System.out.println("str_x=str_z");
		if(str_y == str_m)
			System.out.println("str_y=str_m");
		
		//equalequal and dotequals
		if(str_x == str_y)
			System.out.println("str_x=str_y");		
		if(str_x.equals(str_y))
			System.out.println("--->str_x=str_y");
		
		String str_d="\\shraddha\r  \nfdgdf   \nNandagave%%";
		System.out.println(str_d);
		
	/*
		if(str == str1)
			System.out.println("str=str1");
		else
			System.out.println("str!=str1");
		System.out.println("out of condition\t"+ str +"\t"+str1+"\t"+str2);

		
		if(str2 == str1)
			System.out.println("str2=str1");
		else
			System.out.println("str2!=str1");
		System.out.println("one and two");
		
		if(str2 == str3)
			System.out.println("str2=str3");
		else
			System.out.println("str2!=str3");
			

*/


	}

}
