package stringsDemo;

public class callClass {
	//public int x = 80;
	protected int x=50;
	protected int y=80;
	
	protected void base(){ 
		System.out.print("1. Helo.. base func!\n");
		}
	
	

}
