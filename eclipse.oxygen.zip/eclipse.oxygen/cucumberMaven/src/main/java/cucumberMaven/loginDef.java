package cucumberMaven;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class loginDef {
	WebDriver driver;

	@When("on_facebook page")
	public void on_facebook_page() {
		System.out.println("<----When is executing--->");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shraddha Nandagave\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
		driver= new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);

		driver.get("https://facebook.com");

	}

	@Then("login fb")
	public void login_fb() {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Then is executing");
	}

	@Then("Quit")
	public void quit() {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Quit is executing");
		driver.close();
	}


	@When("^on loginPage$")
	public void on_loginPage() {
		System.out.println("on loginPage");
		String expected= driver.getTitle();
		
	}




}
