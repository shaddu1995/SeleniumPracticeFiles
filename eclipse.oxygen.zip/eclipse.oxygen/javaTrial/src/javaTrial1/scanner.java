package javaTrial1;

import java.io.IOException;

public class scanner {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		System.out.append("\nhelo");
		System.out.print("\nclosed");
		
		System.out.print("\nEnter name");
		int name=  System.in.read();
		System.out.print("Name = "+(int) name);
		
		


	}

}
