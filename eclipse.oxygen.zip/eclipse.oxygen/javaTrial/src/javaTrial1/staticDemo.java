package javaTrial1;

public class staticDemo {

	public static void main(String[] args) {
		demoStatic class1=new demoStatic();
		class1.show();
		System.out.print("x.class1="+class1.x);
		demoStatic class2=new demoStatic();
		class2.show();
		class2.x=10;
		class1.y=15;
		System.out.print("\nx.class1="+class1.x);

		System.out.print( "\nx.class2="+class2.x);

		System.out.print("\nclass1.y="+class1.y);

		System.out.print( "\nclass2.y="+class2.y);
	}

	public static class demoStatic{
		static int x;
		int y;

		static {
			System.out.print("Static method\n");

		}

		demoStatic(){
			this.x=5;
			System.out.print("constructor\n");
		}

		void show() {
			System.out.println("Show");
		}
	}

}
