package Mavenlog;

import org.apache.log4j.Logger;

//import java.util.logging.Logger;

//import org.apache.log4j.Logger;

//import java.util.logging.Logger;



public class MavLog {

	// TODO Auto-generated method stub
	private static Logger Loggg = Logger.getLogger(MavLog.class.getName());
	public static void main(String[] args) 
	{ 
		//Loggg.warning("hellooo");
		Loggg.debug("debug");
		Loggg.error("hello");
		
		
		
		/*Loggg.warn("Warning! You can make it better :-)");
		Loggg.error("Hey, There is an error");
		Loggg.fatal("Execution dead!!!!");*/


	} 

}


