package testngTest;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class testng {

	//SequenceTest
	@BeforeClass
	public void beforeClass() {
		System.out.println("BeforeClass");
	}
	@Test
	public void test() {
		System.out.println("Test");

	}


}
