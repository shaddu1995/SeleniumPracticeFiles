package test;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
@Listeners(ListenerTest.class)

public class testCases {
	@Test
	public void testCase1() {
		System.out.println("[Main]: test body");
	}
	

}
