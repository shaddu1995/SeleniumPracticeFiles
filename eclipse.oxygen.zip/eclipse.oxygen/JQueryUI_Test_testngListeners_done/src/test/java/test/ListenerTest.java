package test;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ListenerTest implements ITestListener {

	
	public void onFinish(ITestContext Result) {
		// TODO Auto-generated method stub
		
	}

	public void onStart(ITestContext Result) {
		// TODO Auto-generated method stub
		
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult Result) {
		// TODO Auto-generated method stub
		
	}

	public void onTestFailure(ITestResult Result) {
		// TODO Auto-generated method stub
		
	}

	public void onTestSkipped(ITestResult Result) {
		// TODO Auto-generated method stub
		
	}
	public void onTestStart(ITestResult Result) {
		// TODO Auto-generated method stub
		System.out.println("\nListener: onTestStert is called :-)");
		
		
	}

	public void onTestSuccess(ITestResult Result) {
		// TODO Auto-generated method stub
		
	}

		
}
