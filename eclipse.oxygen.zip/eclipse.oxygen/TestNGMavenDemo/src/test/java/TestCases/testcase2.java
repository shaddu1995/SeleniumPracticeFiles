package TestCases;

import org.testng.annotations.Test;

public class testcase2{
	@Test
	private void test1() {
		System.out.print("\nprivate testcase");
		
	}

}
