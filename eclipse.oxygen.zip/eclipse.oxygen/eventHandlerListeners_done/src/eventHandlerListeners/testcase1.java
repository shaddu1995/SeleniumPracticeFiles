package eventHandlerListeners;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

public class testcase1 {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shraddha Nandagave\\eclipse-workspace\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		JavascriptExecutor js= (JavascriptExecutor)driver;
		EventFiringWebDriver eventHandler=new EventFiringWebDriver(driver);// eventHandler: to handle driver events
		
		evenCapture eCapture = new evenCapture();
		
		eventHandler.register(eCapture);
		eventHandler.navigate().to("https://jqueryui.com/");
		Thread.sleep(1000);
		eventHandler.navigate().to("https://google.com/");
		Thread.sleep(1000);
		eventHandler.navigate().back();
		Thread.sleep(500);
		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(500);
		System.out.print("\nscriptScroll executed");
		eventHandler.findElement(By.xpath("//a[@href=\"https://jqueryui.com/resizable/\"]")).click();
		System.out.print("\n[main] find by");
		Thread.sleep(3000);
		//js.executeScript("window.scrollBy(0,400)");//scroll with js executer
		
		eventHandler.executeScript("window.scrollBy(0,400)");//scroll with eventHandler
		Thread.sleep(3000);
		
		
				
		eventHandler.unregister(eCapture);
		eventHandler.close();
		
		
		
		
		
		

	}

}
